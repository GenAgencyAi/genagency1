import React, { useState } from 'react';
import { Headphones, Plus, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

const faqs = [
  {
    question: "What platforms do GENAGENCY's AI services work with?",
    answer: "Our AI services integrate seamlessly with all major e-commerce platforms including Shopify, WooCommerce, Magento, and custom solutions. We also support integration with popular CRM systems and marketing tools."
  },
  {
    question: "How are GENAGENCY's services priced?",
    answer: "We offer flexible pricing plans tailored to your business needs. Our packages start from basic AI implementation to full-scale enterprise solutions. Contact us for a customized quote."
  },
  {
    question: "Where can I see examples of GENAGENCY's work?",
    answer: "To get a better understanding of how our AI solutions have transformed e-commerce businesses, we encourage you to check out the case studies featured on our homepage and dedicated case studies page. These examples highlight the breadth of our expertise across various platforms and industries."
  },
  {
    question: "How long does it take to implement GENAGENCY's AI services?",
    answer: "Implementation timelines vary based on the complexity of your needs, typically ranging from 2-8 weeks. We ensure a smooth transition with minimal disruption to your operations."
  },
  {
    question: "Does GENAGENCY offer ongoing management and improvement services?",
    answer: "Yes, at GENAGENCY, we believe that the implementation of AI solutions is just the beginning. We offer monthly management and improvement services to ensure that your e-commerce platform continues to operate at its best, leveraging the latest AI advancements."
  }
];

const Contact = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fullName || !formData.email || !formData.message) {
      setStatus('error');
      setMessage('Please fill in all fields');
      return;
    }

    try {
      setStatus('loading');
      
      const { error } = await supabase
        .from('contacts')
        .insert([{
          full_name: formData.fullName,
          email: formData.email,
          message: formData.message
        }]);

      if (error) throw error;

      setStatus('success');
      setMessage('Thank you for your message! We\'ll get back to you soon.');
      setFormData({ fullName: '', email: '', message: '' });
    } catch (error) {
      setStatus('error');
      setMessage('An error occurred. Please try again.');
      console.error('Contact form error:', error);
    }
  };

  return (
    <div className="relative py-24">
      {/* Get in Touch Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <div className="flex items-center gap-2 mb-4">
          <Headphones className="w-6 h-6 text-purple-400" />
          <span className="text-white text-sm font-medium">Contact us</span>
        </div>
        
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-5xl font-bold text-white mb-6">Get in touch</h2>
            <p className="text-gray-400 mb-8">
              Please feel free to send us any questions, feedback or suggestions you might have.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <input
                  type="text"
                  name="fullName"
                  placeholder="Full Name"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  className="w-full bg-black/50 backdrop-blur-custom border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-black/50 backdrop-blur-custom border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <textarea
                  name="message"
                  placeholder="Message"
                  rows={6}
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full bg-black/50 backdrop-blur-custom border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              {message && (
                <p className={`text-sm ${status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                  {message}
                </p>
              )}
              <button
                type="submit"
                disabled={status === 'loading'}
                className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-6 py-3 rounded-lg transition-all duration-300 disabled:opacity-50"
              >
                {status === 'loading' ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* FAQs Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-6xl font-bold text-white mb-8">FAQs</h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-xl overflow-hidden"
              >
                <button
                  className="w-full px-6 py-4 flex items-center justify-between text-left"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span className="text-white font-medium">{faq.question}</span>
                  {openFaq === index ? (
                    <X className="w-5 h-5 text-gray-400" />
                  ) : (
                    <Plus className="w-5 h-5 text-gray-400" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-400">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;