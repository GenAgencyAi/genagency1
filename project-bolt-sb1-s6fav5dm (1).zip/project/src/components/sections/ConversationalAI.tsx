import React from 'react';
import { DollarSign, Clock, Building2 } from 'lucide-react';

const ConversationalAI = () => {
  return (
    <section className="relative py-24">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Badge */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-custom text-gray-400 text-sm">
            Based on customers' data
          </div>
        </div>

        {/* Heading */}
        <h2 className="text-5xl md:text-6xl font-bold text-center mb-20">
          <span className="text-white">We'll build </span>
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">your own</span>
          <br />
          <span className="text-white">Conversational </span>
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">AI</span>
        </h2>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <DollarSign className="w-8 h-8" />,
              title: "60-80% Open Rate",
              description: "Our AI-driven approach ensures your emails stand out, capturing attention and significantly boosting open rates."
            },
            {
              icon: <Clock className="w-8 h-8" />,
              title: "4-9% Reply Rate",
              description: "Experience a notable increase in engagement with reply rates that far exceed industry averages."
            },
            {
              icon: <Building2 className="w-8 h-8" />,
              title: "20-50 Qualified Leads per month",
              description: "Transform your prospecting efforts with a steady stream of qualified leads."
            }
          ].map((stat, index) => (
            <div
              key={index}
              className="relative group p-8 rounded-2xl bg-white/5 backdrop-blur-custom hover:bg-white/10 transition-all duration-300"
            >
              <div className="text-purple-400 mb-6">{stat.icon}</div>
              <h3 className="text-2xl font-bold text-white mb-4">{stat.title}</h3>
              <p className="text-gray-400 leading-relaxed">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ConversationalAI;