import React from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Jordan',
    position: 'CEO at SportsTech',
    avatar: 'https://i.postimg.cc/xdRJKXG3/replicate-prediction-0vkegxvsbxrj00cmhwdshs145m.webp',
    content: "GenAgency's consultancy redefined our approach to online sales, with Ayoub the way in implementing AI that perfectly understands our sports equipment customers, enhancing satisfaction and loyalty."
  },
  {
    name: 'Mike',
    position: 'CTO at TechFlow',
    avatar: 'https://i.postimg.cc/sDqpXGKB/replicate-prediction-nwgwv0arp9rj20cmhwb9ft9pxm.webp',
    content: "GenAgency's AI solutions catapulted our tech e-commerce to the forefront of innovation, revolutionizing how we interact with customers and manage our online presence."
  },
  {
    name: 'Samantha',
    position: 'Founder at GlamWear',
    avatar: 'https://i.postimg.cc/52z8F9ks/replicate-prediction-4bsysgses1rj20cmhwbtrea5m4.webp',
    content: "Ayoub's insight turned GlamWear into a fashion e-commerce powerhouse. The AI implementation exceeded our expectations in every way."
  },
  {
    name: 'David',
    position: 'Director at FutureRetail',
    avatar: 'https://i.postimg.cc/7b8Zv4ML/replicate-prediction-exbs2m3mhxrj60cmhwfbrbk4vw.webp',
    content: "The AI-driven solutions from GenAgency transformed our customer service. Response times dropped by 80% while satisfaction soared."
  },
  {
    name: 'Emma',
    position: 'COO at StyleHub',
    avatar: 'https://i.postimg.cc/vT14FXJ0/replicate-prediction-xp6m85q7rxrj20cmhwe8vy0jww.webp',
    content: "Working with Thegency was a game-changer. Their AI tools helped us scale our operations while maintaining personalized customer interactions."
  }
];

const ClientTestimonials = () => {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Quote className="w-6 h-6 text-purple-400" />
          <span className="text-white text-sm font-medium">What people say</span>
        </div>
        <h2 className="text-5xl font-bold text-center mb-4">
          <span className="text-white">Our</span>{' '}
          <span className="text-purple-400">Clients</span>{' '}
          <span className="text-white">Feedback</span>
        </h2>
      </div>

      <div className="relative">
        {/* Single row of testimonials */}
        <div className="flex space-x-6 animate-scroll">
          {[...testimonials, ...testimonials].map((testimonial, index) => (
            <div
              key={index}
              className="flex-none w-[400px] bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <h3 className="text-white font-semibold">{testimonial.name}</h3>
                  <p className="text-gray-400 text-sm">{testimonial.position}</p>
                </div>
              </div>
              <p className="text-gray-300">{testimonial.content}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ClientTestimonials;