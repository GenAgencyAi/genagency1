import { AIFeature } from '../ui/AICard';

export const features: AIFeature[] = [
  {
    title: 'AI Lead Generation',
    description: 'Unlock the potential of your sales funnel with our AI Lead Generation service. By leveraging cutting-edge AI technology, we analyze your target market and craft personalized outreach strategies that resonate with each prospect.',
    chatPlaceholder: 'Pls recommend me a pajama',
    chatActions: ['Link', 'Text', 'File']
  },
  {
    title: 'AI Chatbot',
    description: 'Revolutionize your customer service with our AI Chatbot. Available 24/7, it provides instant, accurate responses to your customers\' inquiries, improving their experience while reducing your support team\'s workload.',
    chatPlaceholder: 'Get insights on holiday sales',
    chatActions: ['$']
  },
  {
    title: 'AI Sales Assistant',
    description: 'Enhance your sales team\'s efficiency with our AI Sales Assistant. This innovative tool assists your team in providing personalized customer experiences, navigating complex catalogs with ease, and swiftly finding the right products to meet customer needs.',
    chatPlaceholder: 'Can I get reward for review?',
    chatActions: ['ASK IT NOW', 'UPLOAD REVIEW', 'LOYALTY REWARD']
  }
];