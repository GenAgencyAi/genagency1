import React from 'react';
import { motion } from 'framer-motion';
import { DollarSign, Search, Users, Package, MessageCircle } from 'lucide-react';

const ToolStack = () => {
  const tools = [
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "AI Sales Assistant",
      description: "Leverage AI to offer personalized product suggestions to your customers.",
    },
    {
      icon: <Search className="w-6 h-6" />,
      title: "AI Product Recommender",
      description: "Enhance your customers' shopping experience with smart product recommendations.",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "AI Community Manager",
      description: "Automate interactions on social platforms like Instagram and Facebook.",
    },
    {
      icon: <Package className="w-6 h-6" />,
      title: "AI Inventory Optimizer",
      description: "Predictive stock management with automated reordering system.",
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "AI Support Agent",
      description: "24/7 automated customer support with natural language processing.",
    },
  ];

  const cardAnimation = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 120,
        damping: 10
      }
    }
  };

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center px-4 py-2 rounded-full bg-[#1A1A1A] text-gray-400 text-sm mb-8"
        >
          Designed for your shop
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-5xl font-bold mb-16"
        >
          <span className="text-white">Our </span>
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">
            Tool Stack
          </span>
          <br />
          <span className="text-white">Right Now</span>
        </motion.h2>

        {/* Tools Stack */}
        <div className="relative space-y-4 lg:space-y-8">
          {tools.map((tool, index) => (
            <motion.div
              key={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-20%" }}
              variants={cardAnimation}
              transition={{ delay: index * 0.1 }}
              className="group p-8 rounded-2xl bg-[#1A1A1A]/80 backdrop-blur-sm hover:bg-[#222222] transition-all duration-300 relative"
              style={{ zIndex: tools.length - index }}
            >
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                  {tool.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {tool.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {tool.description}
                  </p>
                </div>
              </div>
              <div className="absolute inset-0 border border-purple-500/20 rounded-2xl pointer-events-none" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ToolStack;