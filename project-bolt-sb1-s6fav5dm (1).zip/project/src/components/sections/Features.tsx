import React from 'react';
import { AICard } from '../ui/AICard';
import { features } from './featuresData';

const Features = () => {
  return (
    <section className="relative py-24" id="features">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">
            AI Solutions That WIN for Your Business
          </h2>
          <p className="text-gray-400">
            CHOOSE YOUR AI WEAPON.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <AICard
              key={index}
              {...feature}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;