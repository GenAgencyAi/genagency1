import React from 'react';

const integrationLogos = [
  {
    name: 'Salesforce',
    url: 'https://www.vectorlogo.zone/logos/salesforce/salesforce-icon.svg'
  },
  {
    name: 'HubSpot',
    url: 'https://www.vectorlogo.zone/logos/hubspot/hubspot-icon.svg'
  },
  {
    name: 'Zendesk',
    url: 'https://www.vectorlogo.zone/logos/zendesk/zendesk-icon.svg'
  },
  {
    name: 'Shopify',
    url: 'https://www.vectorlogo.zone/logos/shopify/shopify-icon.svg'
  },
  {
    name: 'Mailchimp',
    url: 'https://www.vectorlogo.zone/logos/mailchimp/mailchimp-icon.svg'
  },
  {
    name: 'Slack',
    url: 'https://www.vectorlogo.zone/logos/slack/slack-icon.svg'
  },
  {
    name: 'Microsoft Teams',
    url: 'https://www.vectorlogo.zone/logos/microsoft/microsoft-icon.svg'
  },
  {
    name: 'Google',
    url: 'https://www.vectorlogo.zone/logos/google/google-icon.svg'
  },
  {
    name: 'WordPress',
    url: 'https://www.vectorlogo.zone/logos/wordpress/wordpress-icon.svg'
  },
  {
    name: 'Stripe',
    url: 'https://www.vectorlogo.zone/logos/stripe/stripe-icon.svg'
  },
  {
    name: 'Facebook',
    url: 'https://www.vectorlogo.zone/logos/facebook/facebook-tile.svg'
  },
  {
    name: 'LinkedIn',
    url: 'https://www.vectorlogo.zone/logos/linkedin/linkedin-tile.svg'
  },
  {
    name: 'X',
    url: 'https://www.vectorlogo.zone/logos/x/x-icon.svg'
  }
];

const IntegrationBanner = () => {
  return (
    <div className="relative py-16 overflow-hidden">
      <div className="relative">
        <div className="flex space-x-12 animate-scroll" style={{ animationDuration: '9s' }}>
          {[...integrationLogos, ...integrationLogos].map((integration, index) => (
            <div
              key={index}
              className="flex-none w-20 h-20 rounded-xl p-4 hover:bg-white/5 transition-all duration-300 flex items-center justify-center group"
            >
              <img
                src={integration.url}
                alt={integration.name}
                className="w-12 h-12 object-contain opacity-50 group-hover:opacity-100 transition-all duration-300"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IntegrationBanner;
