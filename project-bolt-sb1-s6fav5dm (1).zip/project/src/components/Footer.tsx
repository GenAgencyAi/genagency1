import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setStatus('error');
      setMessage('Please enter your email address');
      return;
    }

    try {
      setStatus('loading');
      
      const { error } = await supabase
        .from('subscriptions')
        .insert([{ email }]);

      if (error) throw error;

      setStatus('success');
      setMessage('Thank you for subscribing!');
      setEmail('');
    } catch (error) {
      setStatus('error');
      setMessage('An error occurred. Please try again.');
      console.error('Subscription error:', error);
    }
  };

  return (
    <footer className="relative text-gray-400">
      {/* Newsletter Section */}
      <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl mx-4 sm:mx-8 lg:mx-auto lg:max-w-7xl p-8 mb-16">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl text-white font-semibold mb-2">
              Get updates on the latest AI Trends in Lead Generation Industry
            </h2>
            <p className="text-gray-500">
              Become a part of our seller community
            </p>
          </div>
          <form onSubmit={handleSubscribe} className="flex flex-col gap-4">
            <div className="flex gap-4">
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-black/50 backdrop-blur-custom border border-white/10 rounded-lg px-4 py-2 focus:outline-none focus:border-purple-500"
              />
              <button 
                type="submit"
                disabled={status === 'loading'}
                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-6 py-2 rounded-lg transition-all duration-300 disabled:opacity-50"
              >
                {status === 'loading' ? 'Subscribing...' : 'Subscribe'}
              </button>
            </div>
            {message && (
              <p className={`text-sm ${status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                {message}
              </p>
            )}
          </form>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center">
              <img 
                src="https://i.postimg.cc/JzJLmCYs/New-Project-1.png" 
                alt="Logo" 
                className="w-[130px]" 
              />
            </div>
            <p className="text-sm">
              Advanced AI Solutions for businesses and corporations.
            </p>
            <div>
              <p className="text-sm">Email Us:</p>
              <a href="mailto:Opportunity@genagency.online" className="text-sm hover:text-purple-400">
                Opportunity@genagency.online
              </a>
            </div>
            <div>
              <p className="text-sm">Gen Agency:</p>
              <p className="text-sm">We build Ai Solutions</p>
              <p className="text-sm">That Talks, Works, and Wins </p>
              <p className="text-sm">For Your Business</p>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-white font-semibold mb-4">Navigation</h3>
            <ul className="space-y-3">
              {['Home', 'Case Studies', 'Pricing', 'Contact Us'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm hover:text-purple-400">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              {[
                'Report a Vulnerability',
                'Data Processing Agreement',
                'Privacy Policy',
                'Terms of Service'
              ].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm hover:text-purple-400">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;