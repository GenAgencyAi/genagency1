import { Calendar, Home, BookOpen, FileText, MessageSquare } from 'lucide-react';
import { NavBar } from "./ui/tubelight-navbar";

export function NavBarDemo() {
  const navItems = [
    { name: 'HOME', url: '/', icon: Home },
    { name: 'CASE STUDIES', url: '/case-studies', icon: BookOpen },
    { name: 'BLOG', url: '/blog', icon: FileText },
    { name: 'CONTACT', url: '/contact', icon: MessageSquare },
    { name: 'SCHEDULE A DEMO', url: '/schedule-demo', icon: Calendar }
  ];

  return <NavBar items={navItems} />;
}