import React from 'react';
import { Link, TextIcon, FileText, DollarSign, ArrowUpRight } from 'lucide-react';
import { ChatInterface } from './ChatInterface';

export interface AIFeature {
  title: string;
  description: string;
  chatPlaceholder: string;
  chatActions: string[];
}

export const AICard: React.FC<AIFeature> = ({ 
  title, 
  description, 
  chatPlaceholder,
  chatActions 
}) => {
  return (
    <div className="relative rounded-2xl bg-white/5 backdrop-blur-custom border border-white/10 p-6 hover:border-purple-500/30 hover:bg-white/10 transition-all duration-300">
      <ChatInterface 
        placeholder={chatPlaceholder}
        actions={chatActions}
      />
      <h3 className="text-purple-400 font-semibold text-xl mb-3">{title}</h3>
      <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
};