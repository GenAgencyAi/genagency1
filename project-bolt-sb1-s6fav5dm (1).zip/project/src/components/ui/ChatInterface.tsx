import React from 'react';
import { Link, TextIcon, FileText, DollarSign, ArrowUpRight } from 'lucide-react';

interface ChatInterfaceProps {
  placeholder: string;
  actions: string[];
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  placeholder,
  actions 
}) => {
  const getIcon = (action: string) => {
    switch(action.toLowerCase()) {
      case 'link':
        return <Link className="w-5 h-5" />;
      case 'text':
        return <TextIcon className="w-5 h-5" />;
      case 'file':
        return <FileText className="w-5 h-5" />;
      case '$':
        return <DollarSign className="w-5 h-5" />;
      default:
        return null;
    }
  };

  return (
    <div className="mb-8 bg-black/50 backdrop-blur-custom rounded-xl p-4">
      <div className="flex items-center space-x-3 mb-4">
        {actions.map((action, index) => (
          getIcon(action) ? (
            <button key={index} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              {getIcon(action)}
            </button>
          ) : (
            <button key={index} className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-gray-300 transition-colors">
              {action}
            </button>
          )
        ))}
      </div>
      <div className="flex items-center">
        <input 
          type="text" 
          placeholder={placeholder}
          className="w-full bg-transparent text-gray-400 text-sm placeholder-gray-600 focus:outline-none"
          readOnly
        />
        <ArrowUpRight className="w-5 h-5 text-gray-600 transform rotate-45" />
      </div>
    </div>
  );
};