import React from 'react';
import { cn } from '../../utils/cn';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className }) => {
  return (
    <div
      className={cn(
        'group relative rounded-xl p-6 transition-all duration-300 hover:scale-105',
        'bg-gradient-to-br from-purple-900/10 to-purple-800/10',
        'hover:shadow-[0_0_30px_rgba(168,85,247,0.15)]',
        'before:absolute before:inset-0 before:rounded-xl before:border before:border-purple-500/0',
        'before:transition-all before:duration-300 hover:before:border-purple-500/50',
        className
      )}
    >
      {children}
    </div>
  );
};

export default Card;