import React from 'react';
import { cn } from '../../utils/cn';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
}

const Button: React.FC<ButtonProps> = ({
  children,
  className,
  variant = 'primary',
  ...props
}) => {
  return (
    <button
      className={cn(
        'px-6 py-2 rounded-full font-medium transition-all duration-300 transform hover:-translate-y-0.5',
        variant === 'primary' &&
          'bg-purple-600 hover:bg-purple-500 text-white hover:shadow-[0_0_15px_rgba(168,85,247,0.5)]',
        variant === 'secondary' &&
          'text-white underline hover:text-purple-300',
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;