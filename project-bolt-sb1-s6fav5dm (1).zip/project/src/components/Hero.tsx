import React from 'react';
import { MessageSquare, Zap, Share2 } from 'lucide-react';
import Button from './ui/Button';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Gradient accents */}
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-purple-600/20 to-transparent blur-3xl" />
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-gradient-to-tr from-purple-600/20 to-transparent blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-16">
        <div className="text-center">
          {/* Main Headline */}
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            Weaponize Your Business with{' '}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
              AI Systems
            </span>{' '}
          </h2>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto mb-12">
            Your Competitors Are Using Us to DOMINATE Leads, Sales & Customer Service—Why Aren’t You?
          </p>

          {/* Key Metrics */}
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
            {[
              {
                icon: <MessageSquare className="w-8 h-8" />,
                title: 'AI Chat & Voice Agents',
                description:
                  'Manage 500+ calls/chats daily, upsell and seal deals 24/7—even when offline.',
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: 'AI Automations',
                description:
                  'Eliminate repetitive work and supercharge efficiency with next-gen AI automations.',
              },
              {
                icon: <Share2 className="w-8 h-8" />,
                title: 'AI Social Media Management',
                description:
                  'Post viral content daily—convert leads to buyers and grow your following 10x faster than any team.',
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-purple-900/10 backdrop-blur-sm rounded-xl p-6 hover:bg-purple-900/20 transition-all duration-300"
              >
                <div className="text-purple-400 mb-4 inline-block">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/schedule-demo">
              <Button>Schedule a Demo</Button>
            </Link>
            <Button variant="secondary">Explore Services</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;