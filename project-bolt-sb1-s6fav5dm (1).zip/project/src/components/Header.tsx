import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const triggerChatEvent = () => {
    window.voiceflow.chat.open({
      launch: {
        event: {
          type: "launch",
          payload: { buttonClicked: "contact_us" }
        }
      }
    });
  };

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-gradient-to-r from-black/95 to-purple-900/95 backdrop-blur-sm shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center text-white hover:text-purple-200 transition-colors">
            <img 
              src="https://i.postimg.cc/JzJLmCYs/New-Project-1.png" 
              alt="Logo"
              className="w-[130px]"
            />
          </Link>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 w-full bg-gradient-to-r from-black/95 to-purple-900/95 backdrop-blur-sm">
          <div className="px-4 py-6 space-y-4">
            <Link
              to="/"
              className={`block text-white hover:text-purple-200 tracking-wider text-sm font-medium transition-colors ${
                location.pathname === '/' ? 'text-purple-400' : ''
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              HOME
            </Link>
            <Link
              to="/case-studies"
              className={`block text-white hover:text-purple-200 tracking-wider text-sm font-medium transition-colors ${
                location.pathname === '/case-studies' ? 'text-purple-400' : ''
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              CASE STUDIES
            </Link>
            <Link
              to="/blog"
              className={`block text-white hover:text-purple-200 tracking-wider text-sm font-medium transition-colors ${
                location.pathname === '/blog' ? 'text-purple-400' : ''
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              BLOG
            </Link>
            <Link
              to="/contact"
              className={`block text-white hover:text-purple-200 tracking-wider text-sm font-medium transition-colors ${
                location.pathname === '/contact' ? 'text-purple-400' : ''
              }`}
              onClick={() => {
                setIsMobileMenuOpen(false);
                triggerChatEvent();
              }}
            >
              CONTACT US
            </Link>
            <Link
              to="/schedule-demo"
              className="block w-full bg-purple-600 hover:bg-purple-500 text-white px-6 py-2 rounded-full font-medium transition-all duration-300 hover:shadow-[0_0_15px_rgba(168,85,247,0.5)] text-center"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Schedule a Demo
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;