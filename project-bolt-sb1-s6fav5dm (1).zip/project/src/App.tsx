import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import ContactPage from './pages/ContactPage';
import BlogPage from './pages/BlogPage';
import BlogPost from './pages/BlogPost';
import CaseStudies from './pages/CaseStudies';
import CaseStudy from './pages/CaseStudy';
import ScheduleDemo from './pages/ScheduleDemo';
import ScrollToTop from './components/ScrollToTop';
import { NavBarDemo } from './components/NavBarDemo';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-black relative overflow-hidden">
        {/* Floating gradient effects */}
        <div className="fixed inset-0 pointer-events-none">
          {/* Floating orb 1 - top right */}
          <div className="absolute top-0 -right-[300px] w-[600px] h-[600px] animate-float-slow">
            <div className="absolute inset-0 rounded-full bg-purple-600/10 blur-3xl" />
          </div>

          {/* Floating orb 2 - bottom left */}
          <div className="absolute -bottom-[300px] -left-[300px] w-[600px] h-[600px] animate-float-slower">
            <div className="absolute inset-0 rounded-full bg-purple-600/10 blur-3xl" />
          </div>

          {/* Floating orb 3 - center right */}
          <div className="absolute top-1/2 -right-[200px] w-[400px] h-[400px] animate-float">
            <div className="absolute inset-0 rounded-full bg-purple-600/5 blur-3xl" />
          </div>

          {/* Floating orb 4 - center left */}
          <div className="absolute top-1/3 -left-[200px] w-[400px] h-[400px] animate-float-slow">
            <div className="absolute inset-0 rounded-full bg-purple-600/5 blur-3xl" />
          </div>

          {/* Additional ambient glow */}
          <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-900/5 to-black opacity-50" />
        </div>

        {/* Content */}
        <div className="relative z-10">
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:id" element={<BlogPost />} />
            <Route path="/case-studies" element={<CaseStudies />} />
            <Route path="/case-studies/:id" element={<CaseStudy />} />
            <Route path="/schedule-demo" element={<ScheduleDemo />} />
          </Routes>
          <Footer />
          <NavBarDemo />
        </div>
      </div>
    </Router>
  );
}

export default App;