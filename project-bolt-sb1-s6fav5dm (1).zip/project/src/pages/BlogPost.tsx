import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import SEO from '../components/SEO';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  author: string;
  image_url: string;
  category: string;
  reading_time: number;
  published_at: string;
  meta_title: string;
  meta_description: string;
  keywords: string[];
  og_title: string;
  og_description: string;
  og_image: string;
  canonical_url: string;
}

const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const { data, error } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('slug', slug)
          .eq('status', 'published')
          .single();

        if (error) throw error;
        setPost(data);
      } catch (error) {
        console.error('Error fetching blog post:', error);
      } finally {
        setLoading(false);
      }
    };

    if (slug) {
      fetchPost();
    }
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black pt-20 flex items-center justify-center">
        <div className="text-gray-400">Loading post...</div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-black pt-20 flex items-center justify-center">
        <div className="text-gray-400">Post not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black pt-20">
      <SEO 
        title={post.meta_title || post.title}
        description={post.meta_description}
        keywords={post.keywords}
        ogTitle={post.og_title}
        ogDescription={post.og_description}
        ogImage={post.og_image}
        canonicalUrl={post.canonical_url}
      />

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Back Button */}
        <Link
          to="/blog"
          className="inline-flex items-center text-gray-400 hover:text-green-500 mb-8 transition-colors"
        >
          <ChevronLeft className="w-5 h-5 mr-2" />
          Back to Blog
        </Link>

        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-gray-400 mb-8">
          <Link to="/" className="hover:text-green-500">Home</Link>
          <span className="mx-2">›</span>
          <Link to="/blog" className="hover:text-green-500">Blog</Link>
          <span className="mx-2">›</span>
          <span>{post.title}</span>
        </div>

        {/* Article */}
        <article>
          <h1 className="text-5xl font-bold text-white mb-8">{post.title}</h1>
          
          <div className="flex items-center mb-8">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop"
              alt={post.author}
              className="w-12 h-12 rounded-full mr-4"
            />
            <div>
              <div className="text-white font-medium">{post.author}</div>
              <div className="text-gray-400 text-sm">
                {post.category} • {post.reading_time} min read
              </div>
            </div>
          </div>

          <div className="aspect-[2/1] mb-8 rounded-2xl overflow-hidden">
            <img
              src={post.image_url}
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="prose prose-invert max-w-none">
            {post.content.split('\n\n').map((paragraph, index) => (
              <p key={index} className="text-gray-300 mb-6 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </article>

        {/* Call to Action */}
        <div className="mt-16 bg-[#1A1A1A] rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Ready to implement AI into your e-comm brand?
          </h3>
          <p className="text-gray-400 mb-6">
            Schedule a free 30-min discovery call with us.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-green-500 text-white px-8 py-3 rounded-full font-medium hover:bg-green-600 transition-colors"
          >
            Schedule a Call →
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BlogPost;