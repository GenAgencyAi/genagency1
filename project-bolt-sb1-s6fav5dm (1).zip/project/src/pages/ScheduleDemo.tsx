import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface FormData {
  fullName: string;
  companyName: string;
  email: string;
  services: string[];
  problemDescription: string;
  additionalInfo: string;
}

const services = [
  'AI Chat & Voice Agents',
  'AI Automations',
  'AI Lead Generation'
];

declare global {
  interface Window {
    Calendly?: any;
  }
}

const ScheduleDemo = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    companyName: '',
    email: '',
    services: [],
    problemDescription: '',
    additionalInfo: ''
  });
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Load Calendly widget script
  useEffect(() => {
    if (step === 4) {
      // Remove any existing Calendly scripts
      const existingScript = document.querySelector('script[src*="calendly"]');
      if (existingScript) {
        existingScript.remove();
      }

      // Create and add the new script
      const script = document.createElement('script');
      script.src = "https://assets.calendly.com/assets/external/widget.js";
      script.async = true;
      script.onload = () => {
        if (window.Calendly) {
          window.Calendly.initInlineWidget({
            url: 'https://calendly.com/ceo-genagency/new-meeting-2',
            parentElement: document.querySelector('.calendly-inline-widget'),
            prefill: {
              name: formData.fullName,
              email: formData.email
            }
          });
        }
      };
      document.body.appendChild(script);

      return () => {
        // Cleanup
        if (existingScript) {
          existingScript.remove();
        }
        script.remove();
      };
    }
  }, [step, formData.fullName, formData.email]);

  const validateStep = (currentStep: number) => {
    const newErrors: Partial<FormData> = {};

    if (currentStep === 1) {
      if (!formData.fullName) newErrors.fullName = 'Full name is required';
      if (!formData.companyName) newErrors.companyName = 'Company name is required';
      if (!formData.email) {
        newErrors.email = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = 'Please enter a valid email';
      }
    } else if (currentStep === 2) {
      if (formData.services.length === 0) newErrors.services = 'Please select at least one service';
    } else if (currentStep === 3) {
      if (!formData.problemDescription) newErrors.problemDescription = 'Please describe your problem';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handlePrevious = () => {
    setStep(step - 1);
  };

  const handleServiceToggle = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = async () => {
    if (validateStep(3) && !isSubmitting) {
      setIsSubmitting(true);
      try {
        const { error } = await supabase
          .from('demo_requests')
          .insert([{
            full_name: formData.fullName,
            company_name: formData.companyName,
            email: formData.email,
            services: formData.services,
            problem_description: formData.problemDescription,
            additional_info: formData.additionalInfo || null
          }]);

        if (error) throw error;
        setStep(4);
      } catch (error) {
        console.error('Error submitting form:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  return (
    <div className="min-h-screen pt-20 bg-black">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between mb-2">
            {['Personal Info', 'Services', 'Project Details', 'Schedule Call'].map((label, index) => (
              <div
                key={label}
                className={`text-sm font-medium ${
                  step > index + 1 ? 'text-purple-400' : step === index + 1 ? 'text-white' : 'text-gray-600'
                }`}
              >
                {label}
              </div>
            ))}
          </div>
          <div className="h-2 bg-gray-800 rounded-full">
            <div
              className="h-full bg-purple-500 rounded-full transition-all duration-300"
              style={{ width: `${((step - 1) / 3) * 100}%` }}
            />
          </div>
        </div>

        {/* Form Steps */}
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={step}
            custom={step}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
          >
            {step === 1 && (
              <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-white mb-6">Personal Information</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-white mb-2">Full Name *</label>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white"
                      placeholder="Enter your full name"
                    />
                    {errors.fullName && <p className="text-red-400 text-sm mt-1">{errors.fullName}</p>}
                  </div>
                  <div>
                    <label className="block text-white mb-2">Company Name *</label>
                    <input
                      type="text"
                      value={formData.companyName}
                      onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white"
                      placeholder="Enter your company name"
                    />
                    {errors.companyName && <p className="text-red-400 text-sm mt-1">{errors.companyName}</p>}
                  </div>
                  <div>
                    <label className="block text-white mb-2">Email *</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white"
                      placeholder="Enter your email"
                    />
                    {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-white mb-6">Service Details</h2>
                <div className="space-y-4">
                  {services.map((service) => (
                    <label
                      key={service}
                      className={`block p-4 rounded-lg border cursor-pointer transition-all ${
                        formData.services.includes(service)
                          ? 'border-purple-500 bg-purple-500/10'
                          : 'border-white/10 hover:border-purple-500/50'
                      }`}
                    >
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.services.includes(service)}
                          onChange={() => handleServiceToggle(service)}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded border mr-3 flex items-center justify-center ${
                            formData.services.includes(service)
                              ? 'bg-purple-500 border-purple-500'
                              : 'border-white/30'
                          }`}
                        >
                          {formData.services.includes(service) && (
                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <span className="text-white">{service}</span>
                      </div>
                    </label>
                  ))}
                  {errors.services && <p className="text-red-400 text-sm">{errors.services}</p>}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-white mb-6">Project Information</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-white mb-2">What specific problems are you looking to solve? *</label>
                    <textarea
                      value={formData.problemDescription}
                      onChange={(e) => setFormData({...formData, problemDescription: e.target.value})}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white h-32"
                      placeholder="Describe your challenges and goals"
                    />
                    {errors.problemDescription && <p className="text-red-400 text-sm mt-1">{errors.problemDescription}</p>}
                  </div>
                  <div>
                    <label className="block text-white mb-2">Additional Information (Optional)</label>
                    <textarea
                      value={formData.additionalInfo}
                      onChange={(e) => setFormData({...formData, additionalInfo: e.target.value})}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white h-32"
                      placeholder="Any other details you'd like to share"
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="bg-white/5 backdrop-blur-custom border border-white/10 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-white mb-6">Schedule a Call</h2>
                <div 
                  className="calendly-inline-widget" 
                  style={{ minWidth: '320px', height: '700px' }}
                />
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          {step > 1 && step < 4 && (
            <button
              onClick={handlePrevious}
              className="flex items-center px-6 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10 transition-colors"
            >
              <ChevronLeft className="w-5 h-5 mr-2" />
              Previous
            </button>
          )}
          {step < 4 && (
            <button
              onClick={step === 3 ? handleSubmit : handleNext}
              disabled={isSubmitting}
              className={`flex items-center px-6 py-2 rounded-lg bg-purple-500 text-white hover:bg-purple-600 transition-colors ml-auto ${
                isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {step === 3 ? (isSubmitting ? 'Submitting...' : 'Submit') : 'Next'}
              <ChevronRight className="w-5 h-5 ml-2" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScheduleDemo;