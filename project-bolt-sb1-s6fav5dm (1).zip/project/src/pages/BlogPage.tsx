import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import SEO from '../components/SEO';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  author: string;
  image_url: string;
  category: string;
  reading_time: number;
  published_at: string;
  slug: string;
  meta_title: string;
  meta_description: string;
  keywords: string[];
}

const BlogPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const { data, error } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('status', 'published')
          .order('published_at', { ascending: false });

        if (error) throw error;
        setBlogPosts(data || []);
      } catch (error) {
        console.error('Error fetching blog posts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  const filteredPosts = blogPosts.filter(post =>
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pt-20">
      <SEO 
        title="Blog - Gen Agency"
        description="Read the latest insights on AI solutions for businesses and corporations"
        keywords={["AI", "business", "automation", "digital transformation"]}
        ogTitle="Gen Agency Blog - AI Solutions Insights"
        ogDescription="Discover the latest trends and insights in AI solutions for businesses"
        ogImage="https://i.postimg.cc/J03sKtZq/replicate-prediction-n2ktf0x4mhrgc0cmhvrt53ppj8.jpg"
      />

      {/* Header */}
      <div className="text-center py-16">
        <h1 className="text-6xl font-bold mb-8">
          <span className="text-white">Read our</span>{' '}
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">Blog Posts</span>
        </h1>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto px-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search something"
              className="w-full bg-[#1A1A1A]/80 backdrop-blur-sm border border-[#333] rounded-full py-3 pl-12 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Blog Grid */}
      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-8 mb-16">
        {loading ? (
          <div className="col-span-3 text-center text-gray-400">Loading posts...</div>
        ) : filteredPosts.length === 0 ? (
          <div className="col-span-3 text-center text-gray-400">No posts found</div>
        ) : (
          filteredPosts.map((post) => (
            <Link 
              key={post.id}
              to={`/blog/${post.slug}`}
              className="group"
            >
              <article className="bg-[#1A1A1A]/80 backdrop-blur-sm rounded-2xl overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                <div className="aspect-video overflow-hidden">
                  <img
                    src={post.image_url}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center text-sm text-gray-400 mb-4">
                    <span>{post.category}</span>
                    <span className="mx-2">•</span>
                    <span>{new Date(post.published_at).toLocaleDateString()}</span>
                    <span className="mx-2">•</span>
                    <span>{post.reading_time} min read</span>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-purple-400 transition-colors">
                    {post.title}
                  </h3>
                  <div className="flex items-center">
                    <img
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop"
                      alt={post.author}
                      className="w-8 h-8 rounded-full mr-3"
                    />
                    <span className="text-gray-400">{post.author}</span>
                  </div>
                </div>
              </article>
            </Link>
          ))
        )}
      </div>
    </div>
  );
};

export default BlogPage;