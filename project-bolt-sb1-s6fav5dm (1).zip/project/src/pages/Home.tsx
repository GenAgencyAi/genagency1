import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/sections/Features';
import ConversationalAI from '../components/sections/ConversationalAI';
import ClientTestimonials from '../components/sections/ClientTestimonials';
import ToolStack from '../components/sections/ToolStack';
import IntegrationBanner from '../components/sections/IntegrationBanner';

const Home = () => {
  return (
    <>
      <Hero />
      <Features />
      <ConversationalAI />
      <ClientTestimonials />
      <ToolStack />
      <IntegrationBanner />
    </>
  );
};

export default Home;