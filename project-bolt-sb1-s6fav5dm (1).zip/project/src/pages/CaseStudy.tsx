import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

const caseStudies = [
  {
    id: 1,
    category: 'AI Shop Butler',
    date: 'Dec 19, 2024',
    readTime: '5 min read',
  title: 'Streamlining Operations at Atlas Artisan Foods with AI Automation',
  content: {
    introduction: "Atlas Artisan Foods, a small but ambitious Moroccan company specializing in handcrafted food products, faced growing pains as their customer base expanded. To enhance operational efficiency and team management, they partnered with us to implement AI-driven automation across key areas of their business.",
    challenge: "Atlas Artisan Foods struggled with inefficient inventory management, time-consuming order processing, and an overwhelmed team. Manual processes were error-prone and slowed down their ability to meet customer demands, hindering their growth potential.",
    solution: {
      title: "AI-Driven Workflow Management for Small Businesses",
      description: "We developed a tailored AI-powered workflow management solution for Atlas Artisan Foods, automating critical processes and enabling their team to focus on innovation and customer engagement. The system addressed their key pain points, including:",
      points: [
        {
          title: "AI-Powered Inventory Management",
          description: "The AI system analyzed sales data and predicted demand, optimizing stock levels and reducing stockouts by 40%. This ensured that popular products were always available, improving customer satisfaction."
        },
        {
          title: "Automated Order Processing",
          description: "The AI solution automated order entry and tracking, reducing processing time by 70%. This allowed the team to focus on delivering exceptional customer service instead of manual data entry."
        },
        {
          title: "AI-Enhanced Team Management",
          description: "An AI scheduling tool optimized shifts and workloads, improving team productivity and morale. By reducing burnout, the team could focus on strategic tasks and innovation."
        }
      ]
    },
    results: {
      title: "Results",
      points: [
        "50% increase in operational efficiency, with tasks completed in minutes instead of hours.",
        "30% reduction in costs due to optimized inventory and reduced manual labor.",
        "25% increase in customer satisfaction thanks to faster order processing and better stock availability."
      ]
    }
},
    author: 'Alpha Bravo',
    image: 'https://i.postimg.cc/RFZm2Fkd/replicate-prediction-1a13qg1sa1rge0cmhw48n6spkc.jpg'
  }
  // Add other case studies here...
];

const CaseStudy = () => {
  const { id } = useParams();
  const study = caseStudies.find(s => s.id === Number(id));

  if (!study) {
    return <div>Case study not found</div>;
  }

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Back Button */}
        <Link
          to="/case-studies"
          className="inline-flex items-center text-gray-400 hover:text-green-500 mb-8 transition-colors"
        >
          <ChevronLeft className="w-5 h-5 mr-2" />
          Back to Case Studies
        </Link>

        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-gray-400 mb-8">
          <Link to="/" className="hover:text-green-500">Home</Link>
          <span className="mx-2">›</span>
          <Link to="/case-studies" className="hover:text-green-500">Case Studies</Link>
          <span className="mx-2">›</span>
          <span>{study.title}</span>
        </div>

        {/* Article */}
        <article>
          <h1 className="text-5xl font-bold text-white mb-8">{study.title}</h1>
          
          <div className="flex items-center mb-8">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop"
              alt={study.author}
              className="w-12 h-12 rounded-full mr-4"
            />
            <div>
              <div className="text-white font-medium">{study.author}</div>
              <div className="text-gray-400 text-sm">{study.category} • {study.readTime}</div>
            </div>
          </div>

          <div className="aspect-[2/1] mb-8 rounded-2xl overflow-hidden">
            <img
              src={study.image}
              alt={study.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="prose prose-invert max-w-none">
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Introduction:</h2>
              <p className="text-gray-300">{study.content.introduction}</p>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Challenge:</h2>
              <p className="text-gray-300">{study.content.challenge}</p>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">{study.content.solution.title}</h2>
              <p className="text-gray-300 mb-4">{study.content.solution.description}</p>
              {study.content.solution.points.map((point, index) => (
                <div key={index} className="mb-4">
                  <h3 className="text-lg font-medium text-white mb-2">{point.title}</h3>
                  <p className="text-gray-300">{point.description}</p>
                </div>
              ))}
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">{study.content.results.title}</h2>
              <ul className="list-disc pl-6 space-y-2">
                {study.content.results.points.map((point, index) => (
                  <li key={index} className="text-gray-300">{point}</li>
                ))}
              </ul>
            </div>
          </div>
        </article>

        {/* Call to Action */}
        <div className="mt-16 bg-[#1A1A1A] rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Ready to implement AI into your e-comm brand?
          </h3>
          <p className="text-gray-400 mb-6">
            Schedule a free 30-min discovery call with us.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-green-500 text-white px-8 py-3 rounded-full font-medium hover:bg-green-600 transition-colors"
          >
            Schedule a Call →
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CaseStudy;