import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = ['All', 'AI Shop Butler', 'AI Brand Manager', 'AI Loyalty Loop', 'Consultancy'];

const caseStudies = [
  {
    id: 1,
    category: 'AI Shop Butler',
    date: 'Nov 19, 2024',
    readTime: '5 min read',
    title: 'From Chaos to Clarity: How Atlas Artisan Foods Transformed Their Business with AI Automation',
    excerpt: 'Discover how Atlas Artisan Foods revolutionized operations with AI, enhancing efficiency and team management.',
    author: 'Alpha Bravo',
    image: 'https://i.postimg.cc/RFZm2Fkd/replicate-prediction-1a13qg1sa1rge0cmhw48n6spkc.jpg'
  },
  {
    id: 2,
    category: 'AI Brand Manager',
    date: 'Dec 2, 2024',
    readTime: '3 min read',
    title: 'Dual Pumps - Revolutionizing Operations with AI Automation',
    excerpt: 'Explore how Dual Pumps leveraged AI automation to streamline biomess processes and workflow',
    author: 'Alpha Bravo',
    image: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=1932&auto=format&fit=crop'
  },
  {
    id: 3,
    category: 'AI Loyalty Loop',
    date: 'Oct 12, 2024',
    readTime: '4 min read',
    title: 'Vush Leverages Quimple AI to Transform Customer Experience',
    excerpt: 'Discover how Vush boosted conversions and educated customers with Quimple AI solutions',
    author: 'Alpha Bravo',
    image: 'https://images.unsplash.com/photo-1581092335397-9583eb92d232?q=80&w=1932&auto=format&fit=crop'
  }
];

const CaseStudies = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredStudies = caseStudies.filter(study => 
    (selectedCategory === 'All' || study.category === selectedCategory)
  );

  return (
    <div className="pt-20">
      {/* Header */}
      <div className="text-center py-16">
        <h1 className="text-6xl font-bold mb-4">
          <span className="text-white">Some of Our</span>{' '}
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">non-NDA</span>
          <br />
          <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">Clients</span>
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto mb-8">
          Most of our clients under NDA agreement, so we can't showcase solutions that we've built for them.
        </p>
        <p className="text-gray-400 max-w-2xl mx-auto mb-12">
          Therefore, we showcase only a select number of case studies approved for public release, ensuring we maintain the competitive edge our services offer our clients.
        </p>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto px-4 mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search something"
              className="w-full bg-[#1A1A1A]/80 backdrop-blur-sm border border-[#333] rounded-full py-3 pl-12 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-purple-500 text-white'
                  : 'bg-[#1A1A1A]/80 backdrop-blur-sm text-gray-400 hover:bg-[#222222]'
              }`}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Case Studies Grid */}
      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-8 mb-16">
        {filteredStudies.map((study) => (
          <Link 
            key={study.id}
            to={`/case-studies/${study.id}`}
            className="group"
          >
            <article className="bg-[#1A1A1A]/80 backdrop-blur-sm rounded-2xl overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
              <div className="aspect-video overflow-hidden">
                <img
                  src={study.image}
                  alt={study.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-400 mb-4">
                  <span>{study.category}</span>
                  <span className="mx-2">•</span>
                  <span>{study.date}</span>
                  <span className="mx-2">•</span>
                  <span>{study.readTime}</span>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-purple-400 transition-colors">
                  {study.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4">{study.excerpt}</p>
                <div className="flex items-center">
                  <img
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop"
                    alt={study.author}
                    className="w-8 h-8 rounded-full mr-3"
                  />
                  <span className="text-gray-400">{study.author}</span>
                </div>
              </div>
            </article>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default CaseStudies;