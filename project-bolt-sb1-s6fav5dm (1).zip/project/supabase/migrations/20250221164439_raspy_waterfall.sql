/*
  # Create demo requests table

  1. New Tables
    - `demo_requests`
      - `id` (uuid, primary key)
      - `full_name` (text, not null)
      - `company_name` (text, not null)
      - `email` (text, not null)
      - `services` (text[], not null)
      - `problem_description` (text, not null)
      - `additional_info` (text)
      - `created_at` (timestamptz, default now())

  2. Security
    - Enable RLS on `demo_requests` table
    - Add policy for anonymous users to insert data
*/

CREATE TABLE IF NOT EXISTS demo_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  company_name text NOT NULL,
  email text NOT NULL,
  services text[] NOT NULL,
  problem_description text NOT NULL,
  additional_info text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE demo_requests ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anonymous users to insert data
CREATE POLICY "Allow anonymous demo requests"
  ON demo_requests
  FOR INSERT
  TO anon
  WITH CHECK (true);