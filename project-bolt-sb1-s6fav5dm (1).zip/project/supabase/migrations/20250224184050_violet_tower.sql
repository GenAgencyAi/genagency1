/*
  # Create Blog Posts Table with SEO Optimization

  1. New Tables
    - `blog_posts`
      - Basic fields: id, title, content, author, image_url, etc.
      - SEO fields: meta_title, meta_description, keywords, etc.
      - Content optimization: slug, reading_time, category, tags, etc.
      - Timestamps and status tracking

  2. Security
    - Enable RLS on blog_posts table
    - Add policies for:
      - Public read access to published posts
      - Authenticated admin write access
*/

-- Create blog_posts table
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Basic Content Fields
  title text NOT NULL,
  content text NOT NULL,
  excerpt text NOT NULL,
  author text NOT NULL,
  image_url text NOT NULL,
  
  -- SEO Fields
  meta_title text,
  meta_description text,
  keywords text[],
  canonical_url text,
  og_title text,
  og_description text,
  og_image text,
  
  -- Content Optimization Fields
  slug text UNIQUE NOT NULL,
  reading_time integer NOT NULL,
  category text NOT NULL,
  tags text[],
  
  -- Status and Timestamps
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  published_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access to published posts
CREATE POLICY "Allow public read access to published posts"
  ON blog_posts
  FOR SELECT
  TO public
  USING (status = 'published');

-- Create policy for authenticated admin write access
CREATE POLICY "Allow authenticated admin write access"
  ON blog_posts
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@genagency.online'
  ))
  WITH CHECK (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@genagency.online'
  ));

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();